/*
BUBBLE SORT
Ascending order -> Answer
largest elemnt is arranged first at the last index and so on 
we use bubble sort in dictionary order 
total number of swaping 
total number of passing =n-1
2,3,1,5,6->2,3,1,5,6->2,1,3,5,6->2,1,3,5,6          (6)
2,1,3,5->1,2,3,5->1,2,3,5->1,2,3,5                  (5)
1,2,3->1,2,3->1,2,3                                 (3)
1,2->1,2                                            (2)
1                                                   (1)
sorted array[1,2,3,5,6]
Questions
=> when do we use bubble sort
=> Sorting technique is used in value or the structure
...Ans it is dependent on value 
=>best case Ω
=>worst case o
=>average case 0
=>space complexity
=>time complexity
=>Is it stable or not
=>Approach
=> is it in place or not
theta 0
big o
omega Ω
*/