/*
Sorting techniques depends on the situation.
it depends on two parameters 
-> time complexity
    execution time of a program that means time taken taken for execution of a program.
-> space complexity
    space that means space taken by the program
Sorting can be performed using several techniques or methods . Some are:-
1. Bubble sort
2. Selection sort
3. Insertion sort
4. Merge sort
5. Quick sort
=> why do we need sorting technique?
Sorting is the process of arranging of the data.
*/ 