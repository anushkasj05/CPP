/*
swaps the adjusent node
=>Is there any differenece between bubble sort and other sorting techniques?
=> what is asymptotic notation?
=> why is asymptotic notation used?
Notion is an unit that is used to measure anything.
we always prepare ourselves for the worst case
we always represent the answer as the ORDER OF N.(O)n 
give the worst data to make the best
brute force algorithm => combination of all possible ways
*/
#include<iostream>
using namespace std;
int main(){
}