/*
stablility(check only if there are duplicate values)
=> if the duplicate values are not swaped than they are stable
in place or not
=> if to solve an array we need to make another array as a back-up there for it will not be inplace
=> if extra memory is taken - not stable
=> if no extra memory is taken - stable
in bubble sort in case of duplicate it is stable
*/