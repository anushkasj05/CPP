/*
approach:- divide and conquer
stability:- not stable as the relevent position is changing.
in place -yes
space complexity :- order of 1
time complexity:- best and average order of n log n and worst case order of n^2
it is value based as well as structure based
*/