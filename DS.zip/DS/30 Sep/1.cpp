/*
STL->Standard Template Library 
class and structure is a non-primitive datatype
types of data structure
->primitive(int,float,char,bool)(already made)
->non-primitive(linear,non-linear)
    linear->array,stack,linked lists,queue(sequence)
    non-linear->tree,graph
Data structure is an arrangement of data in computers memory .
It makes the data quickly available to the processor for required operations.
It allows data to be stored ,organized and accessed so that various operations can be performed easily.
Data structure allocates dynamic memory allocation.
shorting technique is used 
bubble
insertion
selection
quick
merge
EXAM MAI SIRF 5 ALOGRITHM AAYENGE
TEST-1->ALORITHM and numericals 
*/